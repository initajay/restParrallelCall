package com.example.demo.service;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.component.ConcurrentRunner;
import com.example.demo.component.ConcurrentRunnerPimsy;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;
import static java.lang.String.valueOf;
import static java.nio.charset.Charset.defaultCharset;
import static org.apache.commons.io.FileUtils.forceDelete;
import static org.apache.commons.io.FileUtils.write;
import static org.springframework.util.CollectionUtils.isEmpty;
import java.io.File;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import lombok.SneakyThrows;

@Slf4j
@Service
public class ServiceCaller_pimsy {

  @Autowired
  private ExecutorService executorService;


  @Autowired
  private ConcurrentRunnerPimsy runner;
  JSONObject pimsyPaylod = JSONObject.fromObject(
      "{\"pparams\":[{\"name\":\"WeeksOutToCheck\",\"value\":\"2\"},{\"name\":\"UserId\",\"value\":\"632\"},{\"name\":\"MinOpenDurationInMinutes\",\"value\":\"5\"},{\"name\":\"UpdateType\",\"value\":\"baseline\"},{\"name\":\"startDate\",\"value\":\"11/17/2021\"}],\"procedure\":\"cc_DOCASAP_OpenSlots_s\"}");

  JSONObject pimsyPaylod2 = JSONObject.fromObject(
      "{\"pparams\":[{\"name\":\"WeeksOutToCheck\",\"value\":\"2\"},{\"name\":\"UserId\",\"value\":\"427\"},{\"name\":\"MinOpenDurationInMinutes\",\"value\":\"5\"},{\"name\":\"UpdateType\",\"value\":\"baseline\"},{\"name\":\"startDate\",\"value\":\"11/17/2021\"}],\"procedure\":\"cc_DOCASAP_OpenSlots_s\"}");


  JSONObject pimsyPaylod3 = JSONObject.fromObject(
      "{\"pparams\":[{\"name\":\"WeeksOutToCheck\",\"value\":\"2\"},{\"name\":\"UserId\",\"value\":\"53\"},{\"name\":\"MinOpenDurationInMinutes\",\"value\":\"5\"},{\"name\":\"UpdateType\",\"value\":\"baseline\"},{\"name\":\"startDate\",\"value\":\"11/17/2021\"}],\"procedure\":\"cc_DOCASAP_OpenSlots_s\"}");

  JSONObject bookedPayload = JSONObject.fromObject(
      "{\"pparams\":[{\"name\":\"endDate\",\"value\":\"11-30-2021\"},{\"name\":\"UserId\",\"value\":\"427\"},{\"name\":\"UpdateType\",\"value\":\"baseline\"},{\"name\":\"startDate\",\"value\":\"11-22-2021\"}],\"procedure\":\"cc_DOCASAP_Appointment_siud\"}");

  JSONObject bookedPayload2 = JSONObject.fromObject(
      "{\"pparams\":[{\"name\":\"endDate\",\"value\":\"11-30-2021\"},{\"name\":\"UserId\",\"value\":\"53\"},{\"name\":\"UpdateType\",\"value\":\"baseline\"},{\"name\":\"startDate\",\"value\":\"11-22-2021\"}],\"procedure\":\"cc_DOCASAP_Appointment_siud\"}");

  String url = "https://CMPS.pimsyportal.com/secure/api/public";
  String url2 = "https://cust4.pimsyportal.com/secure/api/public";
  String token =
      "4WNahesBE5AIwUk2qlSleeBbXxaYFTEI-dBD5fWbqvAzI68xHBARZsfJWAjl8oazSsUXdUxUlHmjcG_e171hGQ4DAN8ArW47eFIuiZirJvnaol90xT_QO16UAdr2stZ_X1lYEefgysg4aJEN_TXXAzai1pudGBZrag59hP1wszn8a4sDy3VJRllMvqc5InsuLLNjCUafdBdsS3xWTxM29DTU5D3DDFi6Os8fwm8wMOn7KRiors3QBdv4jffx-qcE";

  @PostConstruct
  void getCall() {
    for (int i = 0; i < 10; i++) {
      executorService.submit(new Task(i, url, token, bookedPayload));
      executorService.submit(new Task(i + 100, url, token, bookedPayload2));
    }
  }

  private class Task implements Callable<String> {

    int id;
    String url;
    String token;
    JSONObject payload;

    Task(int id, String url, String token, JSONObject payload) {
      this.id = id;
      this.url = url;
      this.token = token;
      this.payload = payload;

    }

    @Override
    public String call() throws Exception {
      String resp = runner.sendRequest(id, url, payload.toString(), token);
      prepareFile(payload.toString(), "Input/", "url_" + valueOf(id) + ".json");
      prepareFile(resp, "output/", "/response_" + valueOf(id) + ".json");
      log.info("response   :    {}   ", resp);
      return resp;
    }
  }

  @SneakyThrows
  public static File prepareFile(String content, String id, String path) {
    File file = new File(id + path);
    if (!file.exists()) {
      file.getParentFile().mkdirs();
    }
    write(file, content, defaultCharset());
    return file;
  }
}
