package com.example.demo.component;

import static java.lang.String.valueOf;
import static java.nio.charset.Charset.defaultCharset;
import static org.apache.commons.io.FileUtils.write;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.springframework.http.HttpMethod.POST;
import static org.springframework.http.MediaType.APPLICATION_JSON;
import java.io.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;


@Slf4j
@Component
public class ConcurrentRunnerPimsy {

  @Autowired
  private RestTemplate sslRestTemplate;

  private HttpHeaders getHeaders(String token) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(APPLICATION_JSON);
    headers.setBearerAuth(token);
    return headers;
  }

  public String sendRequest(int id,String requestUrl, String payload, String token) {
    
  //  log.info("url -  {}",requestUrl);
   // log.info("payload -  {}",payload);
    try {
      HttpEntity<String> entity = new HttpEntity<>(payload, getHeaders(token));
      ResponseEntity<String> response =
          sslRestTemplate.exchange(requestUrl, POST, entity, String.class);
      if (isEmpty(response.getBody())) {
        log.error("empty response {} ", response.getBody());
      }
      String res = response.getBody();
      prepareFile(payload, "Input/", "url_"+valueOf(id)+".json" );
      prepareFile(res, "output/", "/response_"+valueOf(id)+".json");
      return res;
    } catch (RestClientException e) {
      log.error(e.getMessage(), e);
      return null;
    }
  }
  
  @SneakyThrows
  public static File prepareFile(String content, String id, String path) {
    File file = new File(id + path);
    if (!file.exists()) {
      file.getParentFile().mkdirs();
    }
    write(file, content, defaultCharset());
    return file;
  }
}
