package com.example.demo.component;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import lombok.extern.slf4j.Slf4j;
import net.sf.json.JSONObject;


@Slf4j
@Component
public class ConcurrentRunner {
    
	@Autowired
	private RestTemplate restTemplate;
	
	public JSONObject callEpm(String url, String accessToken) {
		try {
			HttpEntity<String> entity = new HttpEntity<>(getHeaders(false, accessToken));
			ResponseEntity<String> response  = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
			log.info("Status code -- {} ", response.getStatusCode().toString());
			log.info("count --  {} --",JSONObject.fromObject(response.getBody()).get("total"),url);
			return JSONObject.fromObject(response);
		} catch (RestClientException rce) {
			log.error(rce.getMessage()+"  status : ");
			log.error("failed for url   "+url);
		}
		return null;
	}


	private HttpHeaders getHeaders(boolean isUrlEncoded) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		if (isUrlEncoded) {
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		}
		return headers;
	}

	private HttpHeaders getHeaders(boolean isUrlEncoded, String accessToken) {
		HttpHeaders headers = getHeaders(isUrlEncoded);
		headers.set("Authorization", "Bearer "+ accessToken);
		return headers;
	}
	
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.setConnectTimeout(Duration.ofMillis(1000))
				.setReadTimeout(Duration.ofMillis(2000)).build();
	}



   
}