package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.component.ConcurrentRunner;

import net.sf.json.JSONObject;

@Service
public class ServiceCaller {

	@Autowired
	private ExecutorService executorService;
	
	
	@Autowired
	private ConcurrentRunner runner;
	
	
	String url = "https://mtrestapis-test01.dcmedical.org/v1/argoScheduling/STU3/Appointment/$find?location=Location/A21A7AC3-5AA3-459A-984C-BD381EDB5A5B&service-type=73430006&start=2021-03-26&end=2021-03-27";
	String url2 = "https://mtrestapis-test01.dcmedical.org/v1/argoScheduling/STU3/Appointment/$find?location=Location/A21A7AC3-5AA3-459A-984C-BD381EDB5A5B&service-type=73430006&start=2021-03-29&end=2021-03-30";
	String token = "cJfGjiagRGme84TZxqKUEw==";
	
	
	
	void getCall() throws InterruptedException, ExecutionException {
		List<Future<JSONObject>> openAppointmentList = new ArrayList<>();
		for(int i=0;i<100;i++) {
			Future<JSONObject> openAppointment =	executorService.submit(new Task(url, token));
			openAppointmentList.add(openAppointment);
		}
		
		for (Future<JSONObject> openAppointment : openAppointmentList) {
			JSONObject output = openAppointment.get();
			/*
			 * if (!NullChecker.isEmpty(output)) { openAppointmentsArray.addAll(output); }
			 */
		}
		
	}
	

	private class Task implements Callable<JSONObject> {

		String url;
		String token;

		Task(String url, String token) {
			this.url = url;
			this.token = token;

		}

		@Override
		public JSONObject call() throws Exception {
			return runner.callEpm(url, token);
		}
	}
}